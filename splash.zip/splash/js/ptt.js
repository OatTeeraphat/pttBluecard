
$(document).ready(function() {

    $('body').addClass('splash_open');
    $('.splashbtn').click(function() {
        $(this).parent('.splashscreen').fadeOut(200);
        $('body').removeClass('splash_open');
    });

});